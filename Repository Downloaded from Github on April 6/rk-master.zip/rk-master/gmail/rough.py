import math
j = math.sqrt(8)
print (j)

math.deg